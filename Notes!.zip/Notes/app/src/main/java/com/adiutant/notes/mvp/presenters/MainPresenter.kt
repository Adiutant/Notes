package com.adiutant.notes.mvp.presenters

import android.app.Activity
import com.adiutant.notes.NotesApplication
import com.adiutant.notes.db.NoteDao
import com.adiutant.notes.mvp.models.Notes
import com.adiutant.notes.mvp.views.MainView
import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import javax.inject.Inject

//import com.arellomobile.mvp.InjectViewState
//import com.arellomobile.mvp.MvpPresenter
@InjectViewState
class MainPresenter: MvpPresenter<MainView>() {

    @Inject lateinit var mNoteDao: NoteDao
    private lateinit var notesList: MutableList<Notes>

    init {
        NotesApplication.graph.inject(this)
    }
    fun openNote(position:Int)
    {
        viewState.openNoteScreen(position.toLong())
    }
    override fun onFirstViewAttach() {
        super.onFirstViewAttach()
        loadAllNotes()
    }

    fun openNewNote(activity: Activity) {
        val newNote = mNoteDao.createNote()
        notesList.add(newNote)
        openNote(notesList.indexOf(newNote))
    }
    private fun loadAllNotes() {
        notesList = mNoteDao.loadAllNotes()!!
        viewState.onNotesLoaded(notesList)
    }
}