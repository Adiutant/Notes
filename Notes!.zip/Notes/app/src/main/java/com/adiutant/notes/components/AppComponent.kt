package com.adiutant.notes.components

import com.adiutant.notes.db.NoteDaoModule
import com.adiutant.notes.mvp.presenters.MainPresenter
import com.adiutant.notes.mvp.presenters.NotePresenter
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(modules = [NoteDaoModule::class])
interface AppComponent {

    fun inject(mainPresenter: MainPresenter)
    fun inject(notePresenter: NotePresenter)

}