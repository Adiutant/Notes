package com.adiutant.notes.mvp.models


import com.reactiveandroid.annotation.Database

@Database(name = "AppDatabase", version = 1)
class AppDatabase
