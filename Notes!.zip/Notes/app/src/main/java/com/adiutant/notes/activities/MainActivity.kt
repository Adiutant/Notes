package com.adiutant.notes.activities

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.adiutant.notes.R
import com.adiutant.notes.adapters.RecAdapter
import com.arellomobile.mvp.MvpAppCompatActivity
import com.arellomobile.mvp.presenter.InjectPresenter
import com.adiutant.notes.mvp.models.Notes
import com.adiutant.notes.mvp.presenters.MainPresenter
import com.adiutant.notes.mvp.views.MainView
import com.google.android.material.tabs.TabItem
import com.google.android.material.tabs.TabLayout

import kotlinx.android.synthetic.main.activity_main.*
//import com.arellomobile.mvp.presenter.InjectPresenter


class MainActivity : AppCompatActivity(), MainView {
    //private lateinit var adapter: ArrayAdapter<Notes>
    private lateinit var _listView: RecyclerView
    private lateinit var _tabLayout: TabLayout
    private lateinit var _newNote: TabItem

    @InjectPresenter lateinit var  presenter: MainPresenter

    private lateinit var allNotes: ArrayList<Notes>
    //private lateinit var dbHelper: DBHelper
    //private var currentUser = User()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        _listView = findViewById(R.id.taskList)
        _tabLayout = findViewById(R.id.tabLayout)
       // mainPresenter = MainPresenter()
        _tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                presenter.openNewNote(this@MainActivity)
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
                // Handle tab reselect
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                // Handle tab unselect
            }
        })

        //listNotes.add(Notes("Note one",Date(System.currentTimeMillis()),Date(System.currentTimeMillis())))
        //listNotes.add(Notes("Note two",Date(System.currentTimeMillis()),Date(System.currentTimeMillis())))
        //listNotes.add(Notes("Note three",Date(System.currentTimeMillis()),Date(System.currentTimeMillis())))
    }
    override fun onNotesLoaded(notes: List<Notes>) {
        _listView.adapter= RecAdapter(notes)
        updateView()
    }

    override fun updateView() {
        _listView.adapter?.notifyDataSetChanged()
        if (_listView.adapter?.itemCount==0)
        {
            _listView.visibility= View.GONE
        }
        else
        {
            _listView.visibility = View.VISIBLE
        }

    }

    override fun onSearchResult(notes: List<Notes>) {
        TODO("Not yet implemented")
    }

    override fun onAllNotesDeleted() {
        TODO("Not yet implemented")
    }

    override fun onNoteDeleted() {
        TODO("Not yet implemented")
    }

    override fun openNoteScreen(noteId:Long) {
        startActivity(AddNote.buildIntent(this, noteId))
    }


//    private fun act(view: View)
//    {
//        var intent = Intent(this, AddNote::class.java)
//        startActivity(intent)
//    }

}