package com.adiutant.notes.mvp.models


import com.reactiveandroid.Model
import com.reactiveandroid.annotation.Column
import com.reactiveandroid.annotation.Table
import java.util.*


@Table(name = "Notes", database = AppDatabase::class)
class Notes : Model {

    @Column(name = "title")
    var title: String? = null
    @Column(name = "body")
    var text: String? = null
    @Column(name = "change_date")
    var changeDate: Date? = null

    constructor(title: String, changeDate: Date) {
        this.title = title
        this.changeDate = changeDate
    }

    constructor()

//    fun getInfo(): String = "Название:\n$title\n" +
//            "Время создания:\n${formatDate(createDate)}\n" +
//            "Время изменения:\n${formatDate(changeDate)}";
}
