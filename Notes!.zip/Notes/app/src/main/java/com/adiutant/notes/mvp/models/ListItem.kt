package com.adiutant.notes.mvp.models

data class ListItem (
    var header:String
)