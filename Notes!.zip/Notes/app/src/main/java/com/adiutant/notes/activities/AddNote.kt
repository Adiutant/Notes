package com.adiutant.notes.activities

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.adiutant.notes.R
import com.adiutant.notes.db.NoteDao
import com.adiutant.notes.mvp.models.Notes
import com.adiutant.notes.mvp.presenters.MainPresenter
import com.adiutant.notes.mvp.presenters.NotePresenter
import com.adiutant.notes.mvp.views.NoteView
import com.arellomobile.mvp.MvpAppCompatActivity
import com.arellomobile.mvp.presenter.InjectPresenter

class AddNote : MvpAppCompatActivity(),NoteView {
    private lateinit var _backBtn:Button
    private lateinit var _back:Intent
    private lateinit var _saveBtn:Button
    private lateinit var _userMain: Intent
    private lateinit var mainText: EditText
    private var isEdit = false
    private var mNoteDao = NoteDao()
    private  var noteId:Long = 0
    @InjectPresenter
    lateinit var presenter: NotePresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_note)
        _backBtn = findViewById(R.id.backBtn)
        presenter = NotePresenter()
        _saveBtn = findViewById(R.id.saveBtn)
         mainText = findViewById(R.id.mainText)
        _back = Intent(this, MainActivity::class.java)
         noteId = intent.extras?.getLong("note_id", -1)!!
        presenter.showNote(noteId)
        if (noteId.let { mNoteDao.getNoteById(it) } == null) {
                isEdit = true
        }
        doOnClick()

    }

    companion object {
        const val NOTE_DELETE_ARG = "note_id"

        fun buildIntent(activity: Activity, noteId: Long) : Intent{
            val intent = Intent(activity, AddNote::class.java)
            intent.putExtra(NOTE_DELETE_ARG, noteId)
            return intent
        }
    }
    override fun doOnClick()
    {
        _backBtn.setOnClickListener { startActivity(_back) }
        _saveBtn.setOnClickListener {
            if (!isEdit) presenter.saveNote("note", mainText.toString())
            else presenter.editNote("note",mainText.toString(),mNoteDao.getNoteById(noteId)!!)
        }
    }

    override fun showNote(note: Notes) {
        mainText.setText(note.text)
    }

    override fun onNoteSaved() {
        Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show()
    }

    override fun onNoteDeleted() {
        TODO("Not yet implemented")
    }

    override fun showNoteInfoDialog(noteInfo: String) {
        TODO("Not yet implemented")
    }

    override fun hideNoteInfoDialog() {
        TODO("Not yet implemented")
    }

    override fun showNoteDeleteDialog() {
        TODO("Not yet implemented")
    }

    override fun hideNoteDeleteDialog() {
        TODO("Not yet implemented")
    }


//    fun onClickBack()
//    {
//        _backBtn.setOnClickListener(object :View.OnClickListener{
//            override fun onClick(p0: View?) {
//                back(view = View(this))
//            }
//        })
//    }

}