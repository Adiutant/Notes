package com.adiutant.notes.mvp.presenters

import com.adiutant.notes.NotesApplication
import com.adiutant.notes.db.NoteDao
import com.adiutant.notes.mvp.models.Notes
import com.adiutant.notes.mvp.views.NoteView
import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import java.util.*
import javax.inject.Inject

@InjectViewState
class NotePresenter : MvpPresenter<NoteView>() {

    @Inject
    lateinit var mNoteDao: NoteDao
    lateinit var mNote: Notes

    init {
        NotesApplication.graph.inject(this)
    }

    fun saveNote(title: String, text: String) {
        mNote.title = title
        mNote.text = text
        mNote.changeDate = Date()
        mNoteDao.saveNote(mNote)
        //EventBus.getDefault().post(NoteEditAction(note.id))
        viewState.onNoteSaved()
    }
    fun editNote(title: String,text: String,note:Notes)
    {
        var mnote = note
        mnote.title=title
        mnote.text = text
        mnote.changeDate= Date()
        mNoteDao.deleteNote(note)
        mNoteDao.saveNote(mnote)
    }
    fun showNote(noteId: Long) {
        mNote = mNoteDao.getNoteById(noteId)!!
        viewState.showNote(mNote)
    }

}