package com.adiutant.notes

import android.app.Application
import com.adiutant.notes.components.AppComponent
import com.adiutant.notes.components.DaggerAppComponent
import com.adiutant.notes.db.NoteDaoModule



class NotesApplication : Application() {

    companion object {
        var graph: AppComponent = DaggerAppComponent.create()
    }

    override fun onCreate() {
        super.onCreate()
        graph = DaggerAppComponent.builder().noteDaoModule(NoteDaoModule()).build()
    }

}