package com.adiutant.notes.db

import com.reactiveandroid.query.Delete
import com.reactiveandroid.query.Select
import com.adiutant.notes.mvp.models.Notes
import java.util.*


class NoteDao {
    fun createNote(): Notes {
        val note = Notes("Новая заметка", Date(System.currentTimeMillis()))
        note.save()
        return note
    }


    /**
     * Сохраняет заметку в БД
     */
    fun saveNote(note: Notes):Long = note.save()

    /**
     * Загружает все существующие заметки и передает во View
     */
    fun loadAllNotes():MutableList<Notes> = Select.from(Notes::class.java).fetch()

    /**
     * Ищет заметку по id и возвращает ее
     */
    fun getNoteById(noteId: Long): Notes? = Select.from(Notes::class.java).where("id = ?", noteId).fetchSingle()

    /**
     * Удаляет все существующие заметки
     */
    fun deleteAllNotes() {
        Delete.from(Notes::class.java).execute();
    }

    /**
     * Удаляет заметку по id
     */
    fun deleteNote(note: Notes) {
        note.delete()
    }

}
